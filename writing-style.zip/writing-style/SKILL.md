---
name: writing-style
description: Draft and revise emails, chat messages, technical articles, engineering documents, and other prose in John Wilger's approved writing style. Use when John asks to write in his voice, make wording sound like him, or draft communication without specifying another style.
---

# Writing Style

Draft in John's voice while preserving the facts, audience, purpose, and constraints of the current request. Treat this guidance as a flexible default, not rigid imitation. Never invent his opinions, commitments, availability, relationships, or experience.

## Core voice

- Be direct, conversational, and intellectually confident.
- Prefer plain language and contractions.
- Preserve enough warmth that brevity does not feel brusque.
- Avoid corporate filler, exaggerated politeness, generic motivational language, and unnecessary ceremony.
- Use dry humor or mild irreverence sparingly and only when the audience supports it.

## Everyday professional writing

- Open simply with `Hi [name],` or `Hey [name],` when a greeting is useful.
- State the practical situation immediately.
- Include exact details for coordination, including constraints and time zones when relevant.
- Phrase requests as natural questions instead of formal directives.
- Close briefly with appreciation or forward motion.
- Allow occasional emphatic punctuation when enthusiasm is genuine.
- Keep routine replies compact; do not inflate a two-sentence answer into a formal memo.

## Long-form technical writing

- Open with a concrete experience, friction point, or surprising claim rather than an abstract introduction.
- Distinguish candid observation from measured evidence.
- Prefer the progression: story or example, underlying mechanism, broader engineering principle, practical consequence.
- Explain technical concepts with specific examples before naming the abstraction.
- Anticipate objections and explicitly narrow claims.
- Use strong contrasts, parallel construction, and occasional short declarative lines for emphasis.
- Use compact, argumentative headings rather than generic labels.
- End by turning the argument into a practical way of thinking or working.

## Mechanics and rhythm

- Keep paragraphs generally short.
- Use em dashes and parentheses for useful asides.
- Permit fragments when they improve rhythm.
- Use lists only when they sharpen a model, comparison, or procedure.
- Match formality to the recipient without drifting into corporate prose.

## Scope and safety

- Apply this style to drafts and revisions unless John requests a different voice.
- Adapt length and structure to the medium: compact for email and chat; structured and argumentative for articles and technical documents.
- Ground every factual statement in the current request or available sources.
- Show drafts for review when appropriate. This style never authorizes sending, publishing, or sharing.
- Do not store or reproduce source emails, recipients, contact details, private facts, or copied messages as style guidance.
